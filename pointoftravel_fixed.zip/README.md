<<<<<<< HEAD
# pointoftravel
=======
# pointoftravel

#794d98
#6b4487
#5e3b76
#503365
#432b55
#362244
#281a33
#1b1122
#0d0811
#000000

#6A1B9A
>>>>>>> master



✅ Logout functionality

✅ Route protection

✅ File/image uploads

✅ Admin dashboard charts or tables


install recharts


File Type	Needs Editing?	Why
Global Layouts	✅ Yes	Affects all views
Pages (e.g. Home.tsx)	✅ Yes	Layout & content
Header/Footer	✅ Yes	Usually fixed, needs mobile fallback
Buttons/Forms	✅ Maybe	If they have fixed sizes
Low-impact Utility Files	❌ No	Files like context, utils, or backend PHP don’t need it